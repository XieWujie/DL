package com.example.administrator.download

import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import com.example.downloadhelp.DL
import com.example.downloadhelp.request.RequestOptions

class MainActivity : AppCompatActivity() {

    private lateinit var button: Button
    private lateinit var button2: Button

    val s = "https://dl.softmgr.qq.com/original/im/QQ9.1.0.24712-0412.exe"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.button)
        button2 = findViewById(R.id.button2)
        request()
        button2.setOnClickListener {
            test(RequestOptions.MULTI_THREAD)
        }
        button.setOnClickListener {
            test(RequestOptions.SINGLE_THREAD)
        }
    }

    private fun request(){
        if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),1);
        }else{

        }
    }


    private fun test(strategy:Int){
        val r = DL.with(this).load(s).threadMode(strategy).submit()
        r.registerCompleteListener { url, source ->

        }
        r.registerFailListener {
            it.printStackTrace()
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (permissions.isNotEmpty()){

        }
    }
}
