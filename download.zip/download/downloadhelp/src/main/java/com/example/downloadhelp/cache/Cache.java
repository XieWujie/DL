package com.example.downloadhelp.cache;

import java.io.File;

public interface Cache {

    void save(String url, File file);

}
