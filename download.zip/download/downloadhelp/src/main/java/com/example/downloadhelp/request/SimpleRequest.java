package com.example.downloadhelp.request;

import com.example.downloadhelp.cache.Fetch;
import com.example.downloadhelp.cache.Save;
import com.example.downloadhelp.converter.ReadConverter;
import com.example.downloadhelp.converter.WriteEngine;
import com.example.downloadhelp.listener.*;
import com.example.downloadhelp.task.Task;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class SimpleRequest<TransType> extends BaseRequest<TransType> implements OnReadyListener<TransType> {

    protected static Object requestPool = new Object();
    protected SimpleRequest next;
    protected static SimpleRequest sPool;
    protected RequestOptions options;
    protected Task task;
    protected Save save;
    protected Fetch fetch;
    protected ExecutorService executor;
    protected ReadConverter<TransType> readConverter;
    protected TransType result;
    private boolean isRunning = false;
    private boolean isReady = false;
    private Future future;
    private boolean isStop = false;
    private boolean isPause = false;
    private boolean isRecycler = false;


    public SimpleRequest() {

    }


    public SimpleRequest(RequestOptions options, Task task, Save save, Fetch fetch,
                         ExecutorService executor, ReadConverter<TransType> readConverter) {
        init(options,task,save,fetch,executor,readConverter);
    }

    public void init(RequestOptions options, Task task, Save save, Fetch fetch,
                     ExecutorService executor, ReadConverter<TransType> readConverter) {
        this.options = options;
        this.task = task;
        this.save = save;
        this.fetch = fetch;
        this.executor = executor;
        this.readConverter = readConverter;
        task.registerStateListener(this);
    }

    @Override
    public void begin() {
        beforeBegin();
        isReady = true;
        strategy();
    }

    protected void strategy(){
        if (fetch != null) {
            boolean have = fetch.fetch(options.getUrl(), options.resourceType, this);
            if (!have) {
                runTask();
            }
        }else {
            runTask();
        }
    }

    @Override
    public boolean isRecycler() {
        return isRecycler;
    }

    private void runTask(){
        future = executor.submit(task);
    }

    @Override
    public boolean isRunning() {
        return isRunning;
    }


    @Override
    public void cancel() {
        task.cancel();
    }

    @Override
    public void pause() {
        task.pause();
    }

    @Override
    public Future<TransType> get() {
        return future;
    }

    @Override
    public void onReady(TransType transType) {
        for (int i = dlCompleteListeners.size()-1;i>-1;i--){
            dlCompleteListeners.get(i).onComplete(options.getUrl(),transType);
        }
    }


    public static<T> SimpleRequest<T> obtain() {
        synchronized (requestPool) {
            if (sPool != null) {
                SimpleRequest<T> request = (SimpleRequest<T>)sPool;
                sPool = request.next;
                request.next = null;
                return request;
            }
        }
        return new SimpleRequest<T>();
    }

    @Override
    public boolean isPause() {
        return isPause;
    }


    @Override
    public void start() {
        task.start();
    }

    @Override
    public void recycle() {
        synchronized (requestPool) {
            this.task = null;
            this.save = null;
            this.fetch = null;
            this.options = null;
            this.failListeners.clear();
            this.dlCompleteListeners.clear();
            this.isRecycler = true;
            if (sPool == null) {
                sPool = this;
                sPool.next = null;
            } else {
                SimpleRequest request = sPool.next;
                sPool = this;
                sPool.next = request;
            }
        }
    }

    @Override
    public boolean isReady() {
        return isReady;
    }

    protected void beforeBegin(){

    }

    @Override
    public void onState(String url, State state) {
        super.onState(url, state);
        switch (state){
            case CANCEL:{
                isStop = true;
                break;
            }
            case PAUSE:{
                isPause = true;
                break;
            }

        }
    }

    @Override
    public void onComplete(String url, File file) {
        if (readConverter != null) {
            readConverter.convert(options, file, this);
        }else {
            if (File.class == options.resourceType){
                onReady((TransType) file);
            }
        }
    }

}
