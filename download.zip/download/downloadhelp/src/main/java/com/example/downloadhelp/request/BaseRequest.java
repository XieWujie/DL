package com.example.downloadhelp.request;

import com.example.downloadhelp.listener.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

abstract class BaseRequest<Resource> implements Request<Resource>,DLFailListener,DLCompleteListener<File>,StateListener {

    protected List<DLCompleteListener<Resource>> dlCompleteListeners = new ArrayList<>();
    protected List<DLFailListener> failListeners = new ArrayList<>();
    protected List<StateListener> stateListeners = new ArrayList<>();


    @Override
    public void registerCompleteListener(DLCompleteListener completeListener) {
        if (completeListener != null){
            dlCompleteListeners.add(completeListener);
        }
    }


    @Override
    public void registerFailListener(DLFailListener failListener) {
        if (failListener != null){
            failListeners.add(failListener);
        }
    }

    @Override
    public void registerStateListener(StateListener listener) {
        if (listener != null){
            stateListeners.add(listener);
        }
    }

    @Override
    public void onFail(Exception e) {
        for (int i = failListeners.size()-1;i>-1;i--){
            failListeners.get(i).onFail(e);
        }
    }

    @Override
    public void observe(DLListener listener) {

    }

    @Override
    public void onState(String url, State state) {
        switch (state){
            case ERROR:{
                onFail(state.getException());
                break;
            }
            case FINISH:{
                onComplete(url,(File) state.getResult());
                break;
            }
        }
        for (int i = stateListeners.size()-1;i>-1;i--){
           stateListeners.get(i).onState(url,state);
        }
    }

    @Override
    public void registerProgressListener(DLProgressListener listener) {

    }

    @Override
    public void freshProgress() {

    }
}
