package com.example.downloadhelp;

import android.graphics.Bitmap;
import com.example.downloadhelp.converter.BitmapConverter;
import com.example.downloadhelp.converter.ReadConverter;
import com.example.downloadhelp.listener.State;
import com.example.downloadhelp.listener.StateListener;
import com.example.downloadhelp.request.DLRequestBuilder;
import com.example.downloadhelp.request.Request;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.*;

public class DLManager implements StateListener {
    private DL dl;
    private Map<String,Request> requests = new HashMap<String,Request>();
    private ScheduledExecutorService schedule = Executors.newSingleThreadScheduledExecutor();
    private Future progressFuture;


    public Request getRequest(String key){
        return requests.get(key);
    }


    private void freshProgress(){
      for (Request request:requests.values()){
          request.freshProgress();
      }
    }

    private Runnable scheduledTask = new Runnable() {
        @Override
        public void run() {
            freshProgress();
        }
    };

    public void addRequest(String key,Request request){
        requests.put(key,request);
        request.registerStateListener(this);
    }

    public DLRequestBuilder<Bitmap> asBitmap(){
       return asResource(new BitmapConverter(),Bitmap.class);
    }


    public DLManager(DL dl){
        this.dl = dl;
        startProgress();
    }

    public void stopProgress(){
        progressFuture.cancel(false);
    }

    public void startProgress(){
        if (progressFuture == null && progressFuture.isCancelled())
        progressFuture = schedule.scheduleAtFixedRate(scheduledTask,1000,1000,TimeUnit.MILLISECONDS);
    }

    public DLRequestBuilder<File> load(@NotNull String url){
        return asFile().load(url);
    }

    public DLRequestBuilder<File> asFile(){
       return asResource(null,File.class);
    }


    public<ResourceType> DLRequestBuilder<ResourceType> asResource(ReadConverter<ResourceType> readConverter,Class<ResourceType> resourceTypeClass){
        return new DLRequestBuilder<>(dl,this, readConverter,resourceTypeClass);
    }

    @Override
    public void onState(String url, State state) {
        if (state == State.FINISH || state == State.CANCEL ||state == State.ERROR){
            Request request = requests.get(url);
            if (request != null){
                request.recycle();
            }
        }
    }
}
