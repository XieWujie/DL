package com.example.downloadhelp.request;

import com.example.downloadhelp.DL;
import com.example.downloadhelp.DLManager;
import com.example.downloadhelp.cache.Fetch;
import com.example.downloadhelp.cache.Save;
import com.example.downloadhelp.converter.ReadConverter;
import com.example.downloadhelp.listener.State;
import com.example.downloadhelp.listener.StateListener;
import com.example.downloadhelp.task.FileTask;
import com.example.downloadhelp.task.Task;
import org.jetbrains.annotations.NotNull;

public class DLRequestBuilder<TransType> extends RequestOptions<DLRequestBuilder<TransType>,TransType> implements StateListener {

    private DL dl;
    private DLManager dlManager;
    private ReadConverter<TransType> readConverter;
    private Task task;
    private Save save;
    private Fetch fetch;
    private Request<TransType> request;


    public DLRequestBuilder<TransType> load(@NotNull String url){
        this.url = url;
        return this;
    }


    public DLRequestBuilder(DL dl, DLManager dlManager, ReadConverter<TransType> readConverter, Class<TransType> resourceType) {
        this.dl = dl;
        this.dlManager = dlManager;
        this.readConverter = readConverter;
        this.resourceType = resourceType;
        this.save = dl.getSave();
        this.fetch = dl.getFetch();
    }

    public Request<TransType> submit(){
       return buildRequest();
    }

    public DLRequestBuilder apply(Task task){
        this.task = task;
        return this;
    }



    public DLRequestBuilder<TransType>apply(ReadConverter<TransType> readConverter){
        this.readConverter = readConverter;
        return this;
    }


    private Request<TransType> buildRequest(){
        initOptions();
        if (task == null){
            task = new FileTask(this,dl.getExecutor());
        }
        request = ObservableRequest.obtain();
        ((SimpleRequest<TransType>) request).init(this,task,save,fetch,dl.getExecutor(),readConverter);
        Request oldRequest = dlManager.getRequest(url);
        if (oldRequest != null){
            if (oldRequest.isPause()){
                oldRequest.start();
            }
            if (oldRequest.isRunning()){
                oldRequest.registerStateListener(this);
            }
        }else {
            request.begin();
            dlManager.addRequest(url,request);
        }
        return request;
    }

    public void initOptions(){
        if (fileName == null){
            fileName = url.substring(url.lastIndexOf("/"),url.lastIndexOf("?"));
        }
        if (parentPath == null){
            parentPath = dl.getDefaultPath();
        }
    }

    @Override
    public void onState(String url, State state) {
       if (State.CANCEL == state|| state == State.FINISH || state == State.ERROR){
           dlManager.addRequest(url,request);
           request.begin();
       }
    }
}
