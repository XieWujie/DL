package com.example.downloadhelp.listener;

public interface StateListener {
    void onState(String url,State state);
}
