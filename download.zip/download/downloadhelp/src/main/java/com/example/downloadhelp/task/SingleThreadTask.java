package com.example.downloadhelp.task;


import android.os.RecoverySystem;
import com.example.downloadhelp.listener.DLProgressListener;
import com.example.downloadhelp.listener.State;
import com.example.downloadhelp.request.RequestOptions;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

class SingleThreadTask extends AbstractTask {

    private final Object lock = new Object();
    private int downloadLength = 0;
    private RandomAccessFile file;
    private DLProgressListener progressListener;

    public SingleThreadTask(RequestOptions options) {
        super(options);
    }

    @Override
    public File call() throws Exception {
        if (isFileFinish()) {
            File file = new File(filePath);
            succeed(file);
            return file;
        }
        HttpURLConnection connection = null;
        File file = getTargetFile();
        InputStream inputStream = null;
        try {
            connection = getConnection();
            downloadLength = connection.getContentLength();
            long l = file.length();
            if (isSupportMultiLoad(connection)&&l>0) {
                connection.disconnect();
                connection = getConnection();
                inputStream = getBlockStream(connection, l);
            } else {
                file.delete();
                inputStream = connection.getInputStream();
            }
            file = engine(inputStream, l);
        } catch (Exception e) {
            error(e);
            if (connection != null) {
                connection.disconnect();
            }
            close(inputStream);
        }
        return file;
    }

    @Override
    int getTotalLength() {
        return downloadLength;
    }

    @Override
    public int loadedLength() {
        try {
            return (int)( file.getFilePointer());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void registerProgressListener(DLProgressListener listener) {
        this.progressListener = listener;
    }

    public File engine(InputStream inputStream, long start) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        File f = null;
        State state = null;
        try {
            file = new RandomAccessFile(filePath, "rwd");
            file.seek(start);
            byte b[] = new byte[1024];
            int l = -1;
            synchronized (lock) {
                while ((l = bufferedInputStream.read(b)) != -1) {
                    file.write(b,0,l);
                    if (isPause) {
                        state = State.PAUSE;
                        listener.onState(options.getUrl(), state);
                        lock.wait();
                    }
                    if (isCancel) {
                        state = State.CANCEL;
                        listener.onState(options.getUrl(), state);
                        return null;
                    }
                }
            }
            f = new File(filePath);
            succeed(f);
        } catch (Exception e) {
            error(e);
        }
        return f;
    }

    @Override
    public void start() {
        synchronized (lock){
            isPause = false;
            lock.notifyAll();
        }
    }
}