package com.example.downloadhelp.listener;

public  interface DLFailListener extends DLListener{

    void onFail(Exception e);
}
